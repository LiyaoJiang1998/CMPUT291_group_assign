a readme file that lists the names and ccids of all group members

Name: Zhijie Shen CCID: zjshen
Name: Liyao Jiang CCID: liyao1
Name: Hongru Qi CCID:hqi

Disclaimer:
- This group did not collaborate with anyone else
